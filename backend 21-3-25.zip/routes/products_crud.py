from fastapi import APIRouter, HTTPException
from models.product import Product, ProductUpdate
from config.db import products_collection
from bson import ObjectId
from datetime import datetime

# Initialize Router
product_router = APIRouter()

# ------------------------------
# Product Endpoints
# ------------------------------

@product_router.get("/products")
async def get_products():
    """Retrieve all products with full details."""
    products = [
        {**product, "_id": str(product["_id"])}  # Convert ObjectId to string
        for product in await products_collection.find({}).to_list(length=100)
    ]
    return products


@product_router.post("/products")
async def create_product(product: Product):
    """Insert a new product into the database."""
    product_dict = product.dict(by_alias=True, exclude={"id"})

    # Convert HttpUrl objects to strings
    product_dict["images"] = [str(url) for url in product_dict.get("images", [])]

    product_dict["created_at"] = datetime.utcnow().isoformat()
    product_dict["updated_at"] = datetime.utcnow().isoformat()

    result = await products_collection.insert_one(product_dict)
    return {"_id": str(result.inserted_id)}


@product_router.put("/products/{product_id}")
async def update_product(product_id: str, product: ProductUpdate):
    """Modify an existing product by its ID."""
    if not ObjectId.is_valid(product_id):
        raise HTTPException(status_code=400, detail="Invalid Product ID")

    # Only include provided fields in the update
    product_dict = {k: v for k, v in product.dict(exclude_unset=True).items() if v is not None}

    # Convert HttpUrl objects to strings
    if "images" in product_dict:
        product_dict["images"] = [str(url) for url in product_dict["images"]]

    product_dict["updated_at"] = datetime.utcnow().isoformat()

    result = await products_collection.update_one(
        {"_id": ObjectId(product_id)}, {"$set": product_dict}
    )

    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")

    return {"message": "Product updated successfully"}


@product_router.delete("/products/{product_id}")
async def delete_product(product_id: str):
    """Remove a product from the database."""
    if not ObjectId.is_valid(product_id):
        raise HTTPException(status_code=400, detail="Invalid Product ID")

    result = await products_collection.delete_one({"_id": ObjectId(product_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")

    return {"message": "Product deleted successfully"}
